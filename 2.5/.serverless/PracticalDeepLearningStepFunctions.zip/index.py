def handlerMap(event,context):
    return event

def handlerReduce(event,context):
    return event

def handlerBranch(event,context):
    return 'Hello world'